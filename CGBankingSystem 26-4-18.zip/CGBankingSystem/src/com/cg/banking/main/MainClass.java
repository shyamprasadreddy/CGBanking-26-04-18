package com.cg.banking.main;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		
		BankingServicesImpl bankingservices=new BankingServicesImpl();
		//Customer customer=new Customer();
		int customerId=bankingservices.acceptCustomerDetails("shyam", "prasad", "asd@aqs", "asd123", "hyd", "ts", 52042, "kurn", "ap", 1234);
		int customerId1=bankingservices.acceptCustomerDetails("asdf", "prasasad", "asd@daqs", "asd123", "hyd", "ts", 52042, "kurn", "ap", 12345);
		long accountNo=bankingservices.openAccount(customerId, "saving", 1000);
		long accountNo1=bankingservices.openAccount(customerId1, "current", 2000);
		System.out.println(accountNo);
		System.out.println(customerId);
		System.out.println(accountNo1);
		System.out.println(customerId1);
		int pin=bankingservices.generateNewPin(customerId, accountNo);
		System.out.println(bankingservices.getAccountDetails(customerId, accountNo).getPinNumber());
		//bankingservices.withdrawAmount(customerId, accountNo, 100, bankingservices.generateNewPin(customerId, accountNo));
		//System.out.println(bankingservices.generateNewPin(customerId, accountNo));
		//System.out.println(bankingservices.getAccountDetails(customerId, accountNo).getPinNumber());
		//bankingservices.withdrawAmount(customerId, accountNo, 100, pin);
		//bankingservices.depositAmount(customerId, accountNo, 100);
		bankingservices.fundTransfer(customerId1, accountNo1, customerId, accountNo, 100, pin);
		System.out.println(bankingservices.getAccountDetails(customerId, accountNo).getAccountBalance());
		/*Account[] account=bankingservices.getcustomerAllAccountDetails(customerId);
		for (int i = 0; i < account.length; i++) {syso
			System.out.println(account[i].getAccountNo());
		}*/
		System.out.println(accountNo1);
		System.out.println(customerId);
//		//System.out.println(acc);
	//	System.out.println(bankingservices.getCustomerDetails(customerId).getFirstName());
	}
}
